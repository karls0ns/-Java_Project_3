
public class Bus extends Vehicle {

}
